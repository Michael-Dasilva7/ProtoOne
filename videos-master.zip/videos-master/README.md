# IMPORTANT
The olcConsoleGameEngine is lots of fun, but not very portable. If you want a more conventional user experience, but an identical programming experience, which is faster, and very portable, check out the olcPixelGameEngine https://github.com/OneLoneCoder/olcPixelGameEngine

# videos
OneLoneCoder One Off Programs

Hello!

This repo contains all of the source files to the videos on my youtube channel!

www.youtube.com/javidx9

Enjoy them as you see fit, but if you find the content useful, spread the word, give me a shout out, help me out!

Jx9
